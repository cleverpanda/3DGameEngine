#include "camera.h"
#include "matrix.h"
#include "vector.h"

camera_t camera = {
	{0,0,0},
	{0,0,1},
	{0,0,0},
	0.0
};

